The command for running the program, type the following in the command prompt:

python test.py <test_file_name>

check the Label_output file for the labels of k means and dbscan clustering.